############################################################################
############################################################################
####    Getting Started Bot                                     ############
####    File            = ExampleBot.py                         ############    
####    Originaly by    = TryHardHusky                          ############
####    Edited by       = 0rX                                   ############
####    terus di edit lagi sama gugun :v                        ############
####    you can PM for info about making a chatango             ############
####    bot in http://khususme.chatango.com, and you can        ############
####    and you can also chat in :                              ############
####            http://pemakaman.chatango.com                   ############
####    Last update:                                            ############
####            3.21 AM July, 5 2015 by 0rx                     ############
############################################################################
############################################################################

##UPDATE SOURCE BY ITSUKA REHAN. TRUE KENTOT
##Importing Random Crap xD
#here you can see that you're importing ch library
 
import ch
import sys
import re
import json
#import feedparser
#import AllScriptWebsite
#import AllScriptNewPostWebsite
import random
import time
import datetime
import os
import urllib
from xml.etree import cElementTree as ET
if sys.version_info[0] > 2:
  import urllib.request as urlreq
else:
  import urllib2 as urlreq
from time import localtime, strftime 
wordtodaytime = dict() 
##Dance moves!
#kinda useless

cowner = ["r0000000k","t0000000nk","s0000000a","wkf"]##Jangan di ubah karena lu akan melanggar UU No 2 Tentang Hak Cipta.## hak cipta gundul kau
staffa = ["f000000m","s00000","a0000000e","c000e","0000000"]
blacklist = ["abcd"]
dancemoves = [
  "(>^.^)>",
  "(v^.^)v",
]
song = [
  "Dirimu, dirimulah! Orang yang beriku senyum ini",
"Jika kita bisa membuat air mata yang bersinar, itu 'kan 'jadi bintang jatuh",
"Tanganmu t'lah terluka, tapi jangan pernah lepaskannya lagi",
"Dari langit yang terpenuhi keinginan, hari esok 'kan segera datang",

"Cahya yang membimbingku adalah dirimu",
"Dan aku pun ditarik karenanya",
"Sebelum kusadarim kita mulai sebrangi jalan itu",
"Sekaranglah saatnya! Jikalau kita hanya bisa bersinar di sini",
]

bete = [
"kunci",
]
pagi = [
"ohayou oni-chan",
]
## Nicknames
nicks=dict()#empty list
f=open ("nicks.txt","r")#r=read w=right
for line in f.readlines():#loop through eachline and read each line
    try:#try code
        if len(line.strip())>0:#strip the whitespace checkgreater than 0
            user , nick = json.loads(line.strip())
            nicks[user] = json.dumps(nick)
    except:
        print("[Error]Can't load nick %s" % line)
f.close()

locks = []
f = open("locks.txt", 'r')
for name in f.readlines():
  if len(name.strip())>0: locks.append(name.strip())
f.close()
##Rooms##
rooms = []
f = open("rooms.txt", "r") #read-only
print("[INF]Loading Rooms...")
time.sleep(1)
for name in f.readlines():
  if len(name.strip())>0: rooms.append(name.strip())
f.close()
# implied command?	
# call bot name with command after
# call bot name with command after
#Setting Pretty Colors
#Font setting for your bot
# call bot name with command after
# call bot name with command after
#Setting Pretty Colors
#Font setting for your bot
##########################

def getBGTime(x):
                    total_seconds = float(x - time.time())
                    MIN     = 60
                    HOUR    = MIN * 60
                    DAY     = HOUR * 24
                    YEAR    = DAY * 365.25
                    years   = int( total_seconds / YEAR )      
                    days    = int( (total_seconds % YEAR ) / DAY  )
                    hrs     = int( ( total_seconds % DAY ) / HOUR )
                    min = int( ( total_seconds  % HOUR ) / MIN )
                    secs = int( total_seconds % MIN )
                    string = ""
                    if years > 0: string += "<font color='#00ffff'>" + str(years) + "</font> " + (years == 1 and "year" or "years" ) + ", "
                    if len(string) > 0 or days > 0: string += "<font color='#00ffff'>" + str(days) + "</font> " + (days == 1 and "day" or "days" ) + ", "
                    if len(string) > 0 or hrs > 0: string += "<font color='#00ffff'>" + str(hrs) + "</font> " + (hrs == 1 and "hour" or "hours" ) + ", "
                    if len(string) > 0 or min > 0: string += "<font color='#00ffff'>" + str(min) + "</font> " + (min == 1 and "minute" or "minutes" ) + " and "
                    string += "<font color='#00ffff'>" +  str(secs) + "</font> " + (secs == 1 and "second" or "seconds" )
                    return string;
 
def getSTime(x):
                    total_seconds = float(time.time() - x)
                    MIN     = 60
                    HOUR    = MIN * 60
                    DAY     = HOUR * 24        
                    days    = int( total_seconds / DAY )
                    hrs     = int( ( total_seconds % DAY ) / HOUR )
                    min = int( ( total_seconds  % HOUR ) / MIN )
                    secs = int( total_seconds % MIN )
                    string = ""
                    if days > 0: string += "<font color='#00ffff'>" + str(days) + "</font> " + (days == 1 and "day" or "days" ) + ", "
                    if len(string) > 0 or hrs > 0: string += "<font color='#00ffff'>" + str(hrs) + "</font> " + (hrs == 1 and "hour" or "hours" ) + ", "
                    if len(string) > 0 or min > 0: string += "<font color='#00ffff'>" + str(min) + "</font> " + (min == 1 and "minute" or "minutes" ) + " and "
                    string += "<font color='#00ffff'>" +  str(secs) + "</font> " + (secs == 1 and "second" or "seconds", True)
                    return string;

def bgtime(x):
        try:
                x = user if len(x) == 0 else x
                html = urlreq.urlopen("http://st.chatango.com/profileimg/%s/%s/%s/mod1.xml" % (x.lower()[0], x.lower()[1], x.lower())).read().decode()
                inter = re.compile(r'<d>(.*?)</d>', re.IGNORECASE).search(html).group(1)
                if int(inter) < time.time():
                        lbgtime = getSTime(int(inter))
                        return "that users bg ran out %s ago" % lbgtime
                else: return "bgtime for <b>%s</b>: %s" % (x.lower(), getBGTime(int(inter)))
        except: return 'that user never had a background, or the data was deleted'
####gs
def googleImageSearch(encoded):
  encoded = encoded.split()
  url = urllib.request.urlopen("http://ajax.googleapis.com/ajax/services/search/images?v=1.0&q=%s" % "+".join(encoded))
  udict = url.read().decode('utf-8')
  jsonData = json.loads(udict)
  searchResults = jsonData["responseData"]["results"]
  for data in searchResults:
    return  "%s" % (data['url'])

def gis(args):
  fargs = args.split()
  headers = {}
  headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
  req = urllib.request.Request("https://www.google.co.id/search?hl=en&authuser=0&site=imghp&tbm=isch&source=hp&biw=1366&bih=623&q=" + "+".join(fargs), headers = headers)
  resp = urllib.request.urlopen(req).read().decode("utf-8").replace('\n','').replace('\r','').replace('\t','')
  anjay = re.findall('<a href="(.*?)"', resp)
  setter = list()
  la = "".join(anjay)
  if "/imgres?imgurl=" in la[1:]:
     a = re.findall("https://(.*?)&amp", la[15:])
     for result in a:
      if ".jpg" in result or ".gif" in result or ".png" in result:
       return "http://"+"".join(random.choice([result]))

####################################
## Timer Stuff ###############################################

startTime = time.time()

##     End     ###############################################
##############################################################
## Time Stuff ################################################

def getUptime():
  """
  Returns the number of seconds since the programs started.
  """
  #do return startTime if you want the process start time

  return time.time() - startTime

## System Uptime
def uptime():

  try:
    f = open( "/proc/uptime")
    contents = f.read().split()
    f.close()
  except:
    return "Cannot open uptime file"

  total_seconds = float(contents[0])

  ## Helper vars:
  MINUTE = 60
  HOUR = MINUTE * 60
  DAY = HOUR * 24

  ## Get the days, hours, etc:
  days = int( total_seconds / DAY )
  hours = int( ( total_seconds % DAY ) / HOUR )
  minutes = int( ( total_seconds % HOUR ) / MINUTE )
  seconds = int( total_seconds % MINUTE )

  ## Build up the pretty string (like this: "N days. N hours, N minutes, N seconds")
  string = ""
  if days > 0:
    string += str(days) + " " + (days == 1 and "day" or "days" ) + ", "
  if len(string) > 0 or hours > 0:
    string += str(hours) + " " + (hours == 1 and "hour" or "hours" ) + ", "
  if len(string) > 0 or minutes > 0:
    string += str(minutes) + " " + (minutes == 1 and "minute" or "minutes" ) + ", "
  string += str(seconds) + " " + (seconds == 1 and "second" or "seconds" )

  return string;

## End #########################################################
dictionary = dict() #volatile..
f = open("definitions.txt", 'r') #read-only
print("[INF]Loading Definitions...")
time.sleep(1)
for line in f.readlines():
  try:
    if len(line.strip())>0:
      word, definitions, name = json.loads(line.strip())
      dictionary[word] = json.dumps([definitions, name])
  except:
    print("{ERROR]Cant load Definitions: %s" % line)
f.close()
################################################################
def yts(args):
  try:
    search = args.split()
    url = urllib.request.urlopen("https://www.googleapis.com/youtube/v3/search?q=%s&part=snippet&key=AIzaSyD237VSvwgQQB91jSwjCfkDCyZa4PGlYVI&order=relevance&maxResults=1" % "+".join(search))
    udict = url.read().decode('utf-8')
    data = json.loads(udict)
    nest = []
    for d in data["items"]:
      nest.append(d)
    pick=random.choice(nest)
    link = "http://www.youtube.com/watch?v=" + pick["id"]["videoId"]
    title = pick["snippet"]["title"]
    uploader = pick["snippet"]["channelTitle"]
    descript = pick["snippet"]['description']
    count    = pick["snippet"]["publishedAt"]
    k = "<br/>%s <br/><br/><br/><br/><br/><br/><br/><br/><font color='#ffcc00'><b>%s</b></font><br/><font color='#ff0000'><b>Uploader</b></font>:<b> %s</b><br/><font color='#ff0000'><b>Uploaded on</b></font>: %s<br/><font color='#ff0000'><b>Descriptions</b></font>:<i> %s ...</i><br/> " % (link, title, uploader, count, descript[:200])
    print(k)
    return k
  except Exception as e:
    return "Keyword youtube "+args+" tidak tersedia"

def tube(args):
  """
 #In case you don't know how to use this function
 #type this in the python console:
 >>> tube("pokemon dash")
 #and this function would return this thing:
 {'title': 'TAS (DS) Pokﾃｩmon Dash - Regular Grand Prix', 'descriptions': '1st round Grand Prix but few mistake a first time. Next Hard Grand Prix will know way and few change different Pokﾃｩmon are more faster and same course Cup.', 'uploader': 'EddieERL', 'link': 'http://www.youtube.com/watch?v=QdvnBmBQiGQ', 'videoid': 'QdvnBmBQiGQ', 'viewcount': '2014-11-04T15:43:15.000Z'}
 """
  search = args.split()
  url = urlreq.urlopen("https://www.googleapis.com/youtube/v3/search?q=%s&part=snippet&key=AIzaSyAl47M1QiibtSXtq1QbdEsVEUa-0zeW028" % "+".join(search))
  udict = url.read().decode('utf-8')
  data = json.loads(udict)
  rest = []
  for f in data["items"]:
    rest.append(f)
 
  d = random.choice(rest)
  link = "http://www.youtube.com/watch?v=" + d["id"]["videoId"]
  videoid = d["id"]["videoId"]
  title = d["snippet"]["title"]
  uploader = d["snippet"]["channelTitle"]
  descript = d["snippet"]['description']
  count    = d["snippet"]["publishedAt"]
  return "<br/>%s <br/><br/><br/><br/><br/><br/><br/><br/><font color='#ffcc00'><b>%s</b></font><br/><font color='#ff0000'><b>Uploader</b></font>:<b> %s</b><br/><font color='#ff0000'><b>Uploaded on</b></font>: %s<br/><font color='#ff0000'><b>Descriptions</b></font>:<i> %s ...</i><br/> " % (link, title, uploader, count, descript[:200])
# call bot name with command after
# call bot name with command after
#Setting Pretty Colors
#Font setting for your bot
def pm(args):
        user = ch.User(args)
        func = lambda a, b: a.pm._status[b]
        last_on,is_on,idle = func(self, user)
        if is_on == True:
          if idle == 0: room.message(args.capitalize()+" is online and idle for 0 sec",True);return
          else:
                      w = idle
                      w = int(time.time()) - int(w)
                      minute = 60
                      hour = minute * 60
                      day = hour * 24
                      days =  int(w / day)
                      hours = int((w % day) / hour)
                      minutes = int((w % hour) / minute)
                      seconds = int(w % minute)
                      string = " is online and idle for "
                      if days > 0:
                        string += str(days) + " " + (days == 1 and "d" or "d" ) + ", "
                      if hours > 0:
                        string += str(hours) + " " + (hours == 1 and "hr" or "hrs" ) + ", "
                      if minutes > 0:
                        string += str(minutes) + " " + (minutes == 1 and "min" or "mins" ) + ". "
                      room.message(args.capitalize()+string,True)
        else:
          if last_on == 0: room.message(args.capitalize()+" is offline",True);return
          else:
                      w = last_on
                      w = int(time.time()) - int(w)
                      minute = 60
                      hour = minute * 60
                      day = hour * 24
                      days =  int(w / day)
                      hours = int((w % day) / hour)
                      minutes = int((w % hour) / minute)
                      seconds = int(w % minute)
                      string = " is offline for "
                      if days > 0:
                        string += str(days) + " " + (days == 1 and "d" or "d" ) + ", "
                      if hours > 0:
                        string += str(hours) + " " + (hours == 1 and "hr" or "hrs" ) + ", "
                      if minutes > 0:
                        string += str(minutes) + " " + (minutes == 1 and "min" or "mins" ) + ". "
                      room.message(args.capitalize()+string,True)
def getBGTime(x):
                    total_seconds = float(x - time.time())
                    MIN     = 60
                    HOUR    = MIN * 60
                    DAY     = HOUR * 24
                    YEAR    = DAY * 365.25
                    years   = int( total_seconds / YEAR )      
                    days    = int( (total_seconds % YEAR ) / DAY  )
                    hrs     = int( ( total_seconds % DAY ) / HOUR )
                    min = int( ( total_seconds  % HOUR ) / MIN )
                    secs = int( total_seconds % MIN )
                    string = ""
                    if years > 0: string += "<font color='#00ffff'>" + str(years) + "</font> " + (years == 1 and "year" or "years" ) + ", "
                    if len(string) > 0 or days > 0: string += "<font color='#00ffff'>" + str(days) + "</font> " + (days == 1 and "day" or "days" ) + ", "
                    if len(string) > 0 or hrs > 0: string += "<font color='#00ffff'>" + str(hrs) + "</font> " + (hrs == 1 and "hour" or "hours" ) + ", "
                    if len(string) > 0 or min > 0: string += "<font color='#00ffff'>" + str(min) + "</font> " + (min == 1 and "minute" or "minutes" ) + " and "
                    string += "<font color='#00ffff'>" +  str(secs) + "</font> " + (secs == 1 and "second" or "seconds" )
                    return string;
 
def getSTime(x):
                    total_seconds = float(time.time() - x)
                    MIN     = 60
                    HOUR    = MIN * 60
                    DAY     = HOUR * 24        
                    days    = int( total_seconds / DAY )
                    hrs     = int( ( total_seconds % DAY ) / HOUR )
                    min = int( ( total_seconds  % HOUR ) / MIN )
                    secs = int( total_seconds % MIN )
                    string = ""
                    if days > 0: string += "<font color='#00ffff'>" + str(days) + "</font> " + (days == 1 and "day" or "days" ) + ", "
                    if len(string) > 0 or hrs > 0: string += "<font color='#00ffff'>" + str(hrs) + "</font> " + (hrs == 1 and "hour" or "hours" ) + ", "
                    if len(string) > 0 or min > 0: string += "<font color='#00ffff'>" + str(min) + "</font> " + (min == 1 and "minute" or "minutes" ) + " and "
                    string += "<font color='#00ffff'>" +  str(secs) + "</font> " + (secs == 1 and "second" or "seconds", True)
                    return string;

def bgtime(x):
        try:
                x = user if len(x) == 0 else x
                html = urlreq.urlopen("http://st.chatango.com/profileimg/%s/%s/%s/mod1.xml" % (x.lower()[0], x.lower()[1], x.lower())).read().decode()
                inter = re.compile(r'<d>(.*?)</d>', re.IGNORECASE).search(html).group(1)
                if int(inter) < time.time():
                        lbgtime = getSTime(int(inter))
                        return "that users bg ran out %s ago" % lbgtime
                else: return "bgtime for <b>%s</b>: %s" % (x.lower(), getBGTime(int(inter)))
        except: return 'that user never had a background, or the data was deleted'
        
   ## SEBAR JADI AYAM PENYET LU
########################
#### SYSTEM Rainbow ####
########################

def rainbow(word):
    length = len(word)
      #set rgb values
    r = 255 #rgb value set to red by default
    g = 0
    b = 0
    sub = int(1200/length)
    counter = 0
    string = ""
    for x in range(0, length):
        letter = word[counter]
        s = '<f x12%02X%02X%02X="times new roman">%s' % (r, g, b, letter)
        string = string+s
        counter+=1
        if (r == 255) and (g >= 0) and (b == 0):#if all red
            g = g+sub
            if g > 255: g = 255
        if (r > 0) and (g == 255) and (b == 0): #if some red and all green
            r = r-sub                           #reduce red to fade from yellow to green
            if r<0: r = 0                       #if red gets lower than 0, set it back to 0
        if (r == 0) and (g == 255) and (b >= 0):
            b = b+sub
            if b>255:
                b = 255
                trans = True
        if (r == 0) and (g > 0) and (b == 255):
            g = g-sub
            if g<0: g = 0
        if (r >= 0) and (g == 0) and (b == 255):
            r = r+sub
            if r>255: r = 255
    return string

def rainbowtebal(word):
    length = len(word)
      #set rgb values
    r = 255 #rgb value set to red by default
    g = 0
    b = 0
    sub = int(765/length)
    counter = 0
    string = ""
    for x in range(0, length):
        letter = word[counter]
        s = '<f x10%02X%02X%02X="arial"><b>%s</b>' % (r, g, b, letter)
        string = string+s
        counter+=1
        if (r == 255) and (g >= 0) and (b == 0):#if all red
            g = g+sub
            if g > 255: g = 255
        if (r > 0) and (g == 255) and (b == 0): #if some red and all green
            r = r-sub                           #reduce red to fade from yellow to green
            if r<0: r = 0                       #if red gets lower than 0, set it back to 0
        if (r == 0) and (g == 255) and (b >= 0):
            b = b+sub
            if b>255:
                b = 255
                trans = True
        if (r == 0) and (g > 0) and (b == 255):
            g = g-sub
            if g<0: g = 0
        if (r >= 0) and (g == 0) and (b == 255):
            r = r+sub
            if r>255: r = 255
    return string
   
###########################################
### SOURCE GIS CREATED BY ITSUKA REHAN ###
###########################################
def gis(cari):
  argss = cari
  args = argss.split()
  headers = {}
  headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
  req = urllib.request.Request("https://search.aol.com/aol/image?q=" + "+".join(args), headers = headers)
  resp = urllib.request.urlopen(req).read().decode("utf-8").replace('\/','/')
  anjay = re.findall('<div class="sres-cntr">(.*?)</li></ul></div>', resp)
  setter = list()
  la = "".join(anjay)
  a = re.findall('"iurl":"(.*?)"', la)
  q = 1
  for link in a:
      setter.append(link)
      q += 1
  return " - ".join(setter[0:3])
###########################################
### ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ ###
###########################################
   
###########################################
### SOURCE GOS CREATED BY ITSUKA REHAN ###
###########################################
def gs(cari):
  argss = cari
  args = argss.split()
  headers = {}
  headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
  req = urllib.request.Request("https://search.aol.com/aol/image?q=" + "+".join(args), headers = headers)
  resp = urllib.request.urlopen(req).read().decode("utf-8").replace('\/','/')
  anjay = re.findall('<div class="sres-cntr">(.*?)</li></ul></div>', resp)
  setter = list()
  la = "".join(anjay)
  a = re.findall('"rurl":"(.*?)","sigr":"(.*?)","hturl":"","ad":false,"alt":"(.*?)"', la)
  q = 1
  for link, fak, title in a:
      setter.append('<br/><f x12FF0000="times new roman">[<f x12FF00FF="times new roman">%s<f x12FF00FF="times new roman">] <font color="#ff0000"><b>%s</b> </font>:<b></b> %s' % (q, title.capitalize(), link))
      q += 1
  return "<br/><br/>".join(setter[0:4])
###########################################
### ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ ###
###########################################
def sntonick(username):
    user = username.lower()
    if user in nicks:
        nick = json.loads(nicks[user])
        return nick
    else:
        return user
##COMMAN 
##COMMAN
class TestBot(ch.RoomManager):
  def onInit(self):
    self.setNameColor("000")
    self.setFontColor("000")
    self.setFontFace("1")
    self.setFontSize(11)
    self.enableBg()
    self.enableRecording()
##### Pars Def
  def sntonick(username):
    user = username.lower()
    if user in nicks:
        nick = json.loads(nicks[user])
        return nick
    else:
        return user
  def pars(args):
          args=args.lower()
          userlist = roomUsers()
          for name in userlist:
            if args in name:return name  
##Connecting Crap
#This is what will be printed on your python console when event called
 
  def onConnect(self, room):
    print("Connected")
 
  def onReconnect(self, room):
    print("Reconnected")
 
  def onDisconnect(self, room):
    print("Disconnected")
 

##Ignore this, you dont need to worry about this
#Well, you can actually take a little time to look at it and learn something
  def onMessage(self, room, user, message):
  #### Comenzi fara prefix
   if message.body.startswith("hzuki"):
     room.message("iya ada apa ? "+user.name+".")
   if message.body.startswith("aku minta maaf ya"):
     room.message("iya tidak apa  @"+user.name+".")
   if message.body.startswith("domain nekopoi sekarang apa?"):
     room.message(".care")
   if message.body.startswith("hzuki mana yang lainnya"):
     room.message("mungkin sekolah atau sedang sibuk  @"+user.name+".")
   if message.body.startswith("hzuki bagaimana kabarmu"):
     room.message("aku baik baik saja  @"+user.name+".")
   if message.body.startswith("tempat yang paling bagus buat baca horror di mana ya"):
     room.message("pemakamans.blogspot.com  @"+user.name+".")
   if message.body.startswith("xoff"):
     room.message("Ok, besok on lagi ya kk  @"+user.name+".")
   if message.body.startswith("xafk"):
     room.message("dadah  @"+user.name+".")
   if message.body.startswith("neko?"):
     room.message("dimana neko nya?  @"+user.name+".")
   if message.body.startswith("koh"):
     room.message("iya ada apa?   @"+user.name+".")
   if message.body.startswith("hzuki apakah aku cantik"):
     room.message("ya  @"+user.name+".")
   if message.body.startswith("hzuki apakah aku tampan"):
     room.message("ya  @"+user.name+".")
   if message.body.startswith("bott siapa penciptamu"):
     room.message("internet")
   if message.body.startswith(";i"):
     room.message("ver : 1.0 up : (18/Nov/2020)")
   if message.body.startswith("testt"):
     room.message("hmm  @"+user.name+".")
   if message.body.startswith("bott"):
     room.message("prefix ;")
   if message.body.startswith("sepi"):
     room.message("bakar rumah mu saja")
   if message.body.startswith("siang"):
     room.message("selamat siang")
   if message.body.startswith("malam"):
     room.message("selamat malam")
   if message.body.startswith("konbawa"):
     room.message("Konbawa")
   if message.body.startswith("oyasumi"):
     room.message("hai, oyasumi")
   if message.body.startswith("konichiwa"):
     room.message("hai, konichiwa")
   if message.body.startswith("xtime"):
      room.message(strftime("%H:%M:%S", localtime()))      
   if message.body.startswith("xdate"):
     room.message(strftime ("Day: %a,%d-%b-%Y ", localtime()))
   if message.body.startswith("siapa yang paling cantik"):
     room.message("kamu  @"+user.name+".")
   if message.body.startswith("wkkwkwkkw"):
     room.message("kamu baik2 saja  @"+user.name+".")
   if message.body.startswith("aku jahat apa baik ?"):
     jawab = ["jahat","siapa ya? ","baik","pffft :v","coegh"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("halo"):
     room.message("iya halo juga")
   if message.body.startswith("jshsbs"):
     room.message("kamu harus lvl 1 untuk memakainya") 
   if message.body.startswith("kamu udah makan moons ?"):
     jawab = ["aku tidak perlu makan, minum atau buang air"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("moons lagi apa ?"):
     jawab = ["lagi mikrin kamu","lagi bobo","lagi maen dota","siapa ya?","jones ya ?"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("my colors ?"):
     jawab = ["hijau","pelangi","kuning","merah","biru","hitam","ungu","siapa yah ?"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("hai moons"):
     jawab = ["siapa ya ?","hem mungkin","siapa yah ?"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith(" moons lu gapain di sini ?"):
     jawab = ["afk nonton anime"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("kamu suka gak sama aku ?"):
     jawab = ["iya","engak","siapa yah?","suka bnget"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("gue cantik gak moons?"):
     jawab = ["kurang","siapa ya? ","cantik","cantik sih, tapi masih cantikan aku","jones yah ?"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("gue tamvan gak moons?"):
     jawab = ["jelek","siapa ya? ","tamvan","iya kk ganteng deh, aku suka sama kk","jones yah ?"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("tampan gak dia "):
     jawab = ["jelek","siapa ya? ","tamvan","iya kk ganteng deh, aku suka sama kk","jones yah ?"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("soalnya kamu"):
     jawab = ["boleh juga","garing","lagi dong","so swet","siapa yah ?"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("karena kamu"):
     jawab = ["boleh juga","garing","lagi dong","so swet","siapa yah ?"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("asal kamu dari mana moons?"):
     room.message("aku ini sebuah makhluk yang di ciptakan oleh gugun dan aku tidak tau aku berasal dari mana")
   if message.body.startswith("kunci"):
     room.message("muah !!, http://media.giphy.com/media/X3ndlrK6rOCt2/giphy.gif")   
   if message.body.startswith("kunci"):
     room.message(" you want kiss me ?, http://vignette1.wikia.nocookie.net/dundef/images/3/3a/Kawaii-anime-girl-3-kawaii-anime-34732047-400-440.png answer ? (yes,no)  @"+ user.name+".")
   if message.body.startswith("Amoons"):
     room.message("hai!, moons, https://s-media-cache-ak0.pinimg.com/736x/ba/d6/85/bad685e5009bed204ad5aea4ceb16136.jpg ada yang bisa di bantu @"+ user.name+".")
   if message.body.startswith("pagei"):
     for i, msg in enumerate(pagi):
        self.setTimeout(i / 2, room.message, msg)
   if message.body.startswith("bete nih"):
     for i, msg in enumerate(bete):
        self.setTimeout(i / 0.79, room.message, msg)
   if message.body.startswith("nyaasnn"):
      for i, msg in enumerate():
        self.setTimeout(i / 2, room.message, msg)
   if message.body.startswith("kunkuci"):
      for i, msg in enumerate(simponi):
        self.setTimeout(i / 0.79, room.message, msg)
   if message.body.startswith(";katabot"):
      room.message(random.choice(["jangan lah berhenti bermimpi karena mimpi bisa itu suatu saat akan menjadi nyata.",
          "berani ambil resiko, kita tidak akan pernah tau apa yang akan terjadi.",
          "jangan pernah lupa dengan orang yang selalu mendukung mu dari belakang.",
          "jangan pernah sekali-kali sombong, karena di atas langit masih ada langit.",
          "To true friendship, how long you've known each other means nothing.",
          "You want weapons? We??re in a library! Books! The best weapons in the world!",
          "mulut lebih tajam dari benda apapun kalu kita salah menggunakan nya.",
          "Dividing an impossibly large task into smaller solvable problems is a programmer??s job.",
          "dunia ini penuh dengan melodi dan harmoni, jangan sekali2 merusak nya dengan keluhan anda :)",
          "Hold hands. That's what you're meant to do. Keep doing that... and don't let go.",
          "cintailah orang yang mencintai anda juga?",
          "jangan pernah malah olahraga",
          "Don't worry if plan A fails, there are 25 more letters in the alphabet.",
          "Life doesn't have any hands, but it can sure give you a slap sometimes.",
          "lihat ke belakang, sewaktu2 jika anda tidak sedang sibuk",
          "Belajar ketika orang lain tidur, bekerja ketika orang lain bermalasan, dan bermimpi ketika orang lain berharap.",
          "Pain has deep roots. The only way to dig it out is to forgive...",
          "Love,after all,always said more about those who felt it then it did about the ones they love.",
          "Memories are funny things.Sometimes they're real ,but other times they change into what we went them to be.",
          "The moment of impact. The moment of impact proves potential for change. Has ripples effects far beyond what we can predict."]))
   if message.body.startswith(";quotes"):
      room.message(random.choice(["jangan lah berhenti bermimpi karena mimpi bisa itu suatu saat akan menjadi nyata.",
          "berani ambil resiko, kita tidak akan pernah tau apa yang akan terjadi.",
          "jangan pernah lupa dengan orang yang selalu mendukung mu dari belakang.",
          "jangan pernah sekali-kali sombong, karena di atas langit masih ada langit.",
          "To true friendship, how long you've known each other means nothing.",
          "You want weapons? We??re in a library! Books! The best weapons in the world!",
          "mulut lebih tajam dari benda apapun kalu kita salah menggunakan nya.",
          "Dividing an impossibly large task into smaller solvable problems is a programmer??s job.",
          "dunia ini penuh dengan melodi dan harmoni, jangan sekali2 merusak nya dengan keluhan anda :)",
          "Hold hands. That's what you're meant to do. Keep doing that... and don't let go.",
          "cintailah orang yang mencintai anda juga?",
          "jangan pernah malah olahraga",
          "Don't worry if plan A fails, there are 25 more letters in the alphabet.",
          "Life doesn't have any hands, but it can sure give you a slap sometimes.",
          "lihat ke belakang, sewaktu2 jika anda tidak sedang sibuk",
          "Belajar ketika orang lain tidur, bekerja ketika orang lain bermalasan, dan bermimpi ketika orang lain berharap.",
          "Pain has deep roots. The only way to dig it out is to forgive...",
          "Love,after all,always said more about those who felt it then it did about the ones they love.",
          "Memories are funny things.Sometimes they're real ,but other times they change into what we went them to be.",
          "The moment of impact. The moment of impact proves potential for change. Has ripples effects far beyond what we can predict."]))
   if message.body.startswith("ramalan jodoh"):
     room.message("masukan nama mu dan pasangan mu contoh >> mr.x dan ms.y setelah itu tulis >> ramal")
   if message.body.startswith("gua cocok gak sama"):
      jawab = ["cocok","gak cocok","gak pantes","saling suka :)",]
      room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("brb"):
     if user.name == "noss":
      room.message("jangan balik lagi ya")
     else:
      room.message("sampai ketemu lagi  "  + user.name+".")
   if message.body.startswith("nossse"):
     if user.name == "noss":
      room.message("iya ada apa..?")
     else:
      room.message("selamat datang  tuan/nyonya   "  + user.name+".")
   try:
    if room.getLevel(self.user) > 0:
      print(user.name, message.body)
    else:
      print(user.name, message.body)
    if self.user == user: return
    if message.body[0] == ";" :   ##Here is the Prefix part
      data = message.body[1:].split(" ", 1)
      if len(data) > 1:
        cmd, args = data[0], data[1]
      else:
        cmd, args = data[0], ""

      def roompars(args):
        args = args.lower()
        for name in self.roomnames:
          if args in name:return name
      def roomUsers():
          usrs = []
          gay = []
          prop = 0
          prop = prop + len(room._userlist) - 1
          for i in room._userlist:
            i = str(i)
            usrs.append(i)
          while prop >= 0:
            j = usrs[prop].replace("<User: ", "")
            i = j.replace(">", "")
            gay.append(i)
            prop = prop - 1
          return gay
      
      def getParticipant(arg):
          rname = self.getRoom(arg)
          usrs = []
          gay = []
          finale = []
          prop = 0
          prop = prop + len(rname._userlist) - 1
          for i in rname._userlist:
            i = str(i)
            usrs.append(i)
          while prop >= 0:
            j = usrs[prop].replace("<User: ", "")
            i = j.replace(">", "")
            gay.append(i)
            prop = prop - 1
          for j in gay:
            if j not in finale:
              finale.append(j)
          return finale
##COMMANDS!
##COMMANDS!
      if cmd == "yt" or cmd == "youtube":
        if args:
          room.message(yts(args),True)
        else:
          room.message("Please type what you want to watch in Youtube..",True)

	   ###Undefine
      if cmd == "udf" and len(args) > 0:
          try:
            word = args
            if word in dictionary:
              definition, name = json.loads(dictionary[word])
              if name == user.name or self.getAccess(user) >= 3:
                del dictionary[word]
                f =open("definitions.txt", "w")
                for word in dictionary:
                  definition, name = json.loads(dictionary[word])
                  f.write(json.dumps([word, definition, name])+"\n")
                f.close
                room.message(args+" has been removed from Definition database")
                return
              else:
                room.message("<b>%s</b> you can not remove this define only masters or the person who defined the word may remove definitions" % user.name, True)
                return
            else:
               room.message("<b>%s</b> is not yet defined you can define it by typing <b>define %s: meaning</b>" % args, True)
          except:
            room.message("Gagal")
            return

#Setting up commands for yer bot
 #commands section
 
      if cmd == "xlock":
        if user.name in blacklist:
          room.message("You can't do that.. o,o")
          return
        if args in locks:
          room.message("It's already locked.. o,o")
          return
        if args in self.roomnames:
          if user.name in cowner or user.name in staffa:
            locks.append(args)
            room.message("Locked: <b>%s</b>" % args, True)
          else: room.message("Only rank 3 gets to lock rooms remotely")
        if args == "":
          if room.name in locks:
            room.message("It's already locked.. o,o")
            return
          locks.append(room.name)
          room.message("Locked: <b>%s</b>" % room.name, True)
        if args not in self.roomnames:
          if args == "": return
          room.message("I haven't joined such room")
          return
      if cmd == "xunlock":
        if user.name in blacklist: return
        if args in self.roomnames:
          if args in locks:
            if user.name in cowner or user.name in staffa:
              locks.remove(args)
              room.message("Unlocked: <b>%s</b> o,o" % args, True)
            else: room.message("")
          else:
            room.message("It's not even locked.. o,o")
            return
        if args == "":
          if room.name in locks:
            locks.remove(room.name)
            room.message("Unlocked: <b>%s</b> o,o" % room.name, True)
          else:
            room.message("It's not even locked.. o,o")
            return
        if args not in self.roomnames:
          if args == "": return
          room.message("I'm not in that room.. o,o")
          return

      if message.body.lower() == "*lockstatus":
            roomlock = "No"
            if room.name in locks:
              locks.remove(room.name)
              roomlock = "Yes"
              self.setTimeout(3, locks.append(room.name), True)
              room.message("This is my lockstatus: <br/>[Roomlocked]: <b>"+roomlock, True)
              
                                             #########################
                                             ## Check Status Online ##
                                             #########################


      if cmd == "cso" or cmd=="checkstatusonline":
        try:
          resp = urlreq.urlopen("http://"+args+".chatango.com").read().decode()
          fap = bool('chat with' in resp.lower())
          fapper = ""
          if fap == True:
            fapper += "<b>Online</b>"
          if fap == False:
            fapper += "<b>Offline</b>"
          room.message(args+" is "+fapper+", more info: http://"+args+".chatango.com/i?17",True)
        except:
          room.message(args+" is not exist..")

                                             ##########
                                             ## Find ##
                                             ##########

      if cmd == "find" and len(args) > 0:
        name = args.split()[0].lower()
        if not ch.User(name).roomnames:
          room.message("dia sedang offline, mungkin dia lagi bertapa.")
        else:
          room.message("kamu dapat menemukan  %s Di %s" % (args, ", ".join(ch.User(name).roomnames)),True)
          
      if cmd == "ping":
         if args == "":
          usrs = []
          gay = []
          finale = []
          prop = 0
          prop = prop + len(room._userlist) - 1
          for i in room._userlist:
            i = str(i)
            usrs.append(i)
          while prop >= 0:
            j = usrs[prop].replace("<User: ", "")
            i = j.replace(">", "")
            gay.append(i)
            prop = prop - 1
          for i in gay:
            if i not in finale:
              finale.append(i)
          if len(finale) > 40:
            room.message("@%s"% (" @".join(finale[:41])), True)
                
          if len(finale) <=40 :
            room.message("@%s"% (" @".join(finale)), True)
                
         if args == "":
           if args not in self.roomnames:
             room.message("I'm not there.")
                  
             return


                                             #############
                                             ## Rainbow ##
                                             #############
#RB1
      if cmd == "rb":
        if args == "":
          rain = rainbow('Rainbow')
          room.message(rain,True)
                      
        else: 
          rain = rainbow(args)
          room.message(rain,True)
#RB2
      if cmd == "rb2":
        if args == "":
          rain = rainbow('Rainbow')
          room.message(rain)
                    
        else: 
          rain = rainbow(args)
          room.message(rain)
          
                                             #################
                                             ## Random User ##
                                             #################

      if cmd == "randomuser" or cmd == "ru":
        room.message(random.choice("@"+room.usernames))

     ###############
     ### Restart ###
     ###############
      if cmd == "rejoin":
         (lambda x,y: [x.joinRoom(z) for z in y])(self,rooms)
         room.message("ReCrot All Room Sucses") 
#### MEMEK MEMEK MEMEK 
      if cmd == "gs":
            room.message("<br/>Result : <br/>" + gs(args), True)

      if cmd == "gis" or cmd == "google_image_search" or cmd == "gimagesearch":
        if args:
          room.message(gis(args),True)
        else:
          room.message("Please type what you want to watch in Memek Image..",True)
#### Invite
      if cmd == "invite" or cmd == "Invite":
        if len (args) > 0:
            self.pm.message(ch.RoomManager(args),"%s You have a group invite by ! http://%s.chatango.com ." %(owners[0],room.name))
            room.message("Invite on progress %s in Access group. :)" % args)
        else:
            room.message("Sry have problem. :3")
##bgtime
      if cmd == "bgtime": room.message(bgtime(args), True)
##You may want/need to evaluate something about your bot.
      if cmd == "ev" or cmd == "eval" or cmd == "e":
          ret = eval(args)
          if ret == None:
            room.message("Done.")
            return
          room.message(str(ret))
      if cmd.lower() == "fpix" and len (args) > 0:
        if self.getAccess(user) >= 0:
            name=args
            room.message("http://fp.chatango.com/profileimg/"+name[:1]+"/"+name[1:2]+"/"+name+"/full.jpg")
        
        ##cso
        if cmd == "cso":
          if not args:
              room.message("Usage : +cso <b>[user name]</b>")
          if args:
            self.pm.addContact(ch.User(args))
            self.setTimeout(2, self.pm.track, (ch.User(args)))
            self.setTimeout(5, pm, (args))
        ##Say
        #Make your bot say what you want
      if cmd == "say":
       if args:
        room.message(args)
       else:
        room.message(":|")
      elif cmd == "cmds" or cmd =="command":
        room.message("Available Command: <br/> yt , prof , pm ,   quotes , time , join , leave , mylvl ,ramal , help , say , randomuser , invite , rooms , mods , date , afk ,ismod , ig , ul , ev , bg , find , uptime , sut , seen , multichat , bgt , cso , jones , df , mydf , lm , save (untk save df) , katabot , udf , bgtime , ", True)
      # clear
      elif cmd == "xclear":
          if room.getLevel(self.user) > 0:
            if self.getAccess(user) >= 5 or room.getLevel(user) == 2:
              room.clearall(),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
            else: room.message("Only rank 4+ or the room owner can do this")
          else:
            room.message("aku bukan mods disini :|")
      ##delete chat  
      elif (cmd == "xdelete" or cmd == "xdl" or cmd == "xdel"):
          if room.getLevel(self.user) > 0:
            if self.getAccess(user) >= 1 or room.getLevel(user) > 0:
              name = args.split()[0].lower()
              room.clearUser(ch.User(name))
            else:room.message("kamu tidak bisa melakukannya!!")
          else:
            room.message("aku bukan mods disini :|")
      elif cmd == "nick":
        ## if user.name in reg or user.name in friends or user.name in trusted or user.name in owners:
            if args:
                nick = args # disini letak perbedaannya...
                user = user.name # mungkin juga disini
                nicks[user] = json.dumps(nick)
                room.message(user +' I will now call you '+str(args)+'', True)
                try: # ini skrip untuk auto-save ...
                    print("[SAVING] NICKS...")
                    f = open("nicks.txt", "w")
                    for user in nicks:
                        nick = json.loads(nicks[user])
                        f.write(json.dumps([user,nick]) + "\n")
                except:
                       room.message("Failed To Make New Nick..");return
            else:
              room.message('Type ;nick yournick to adding new nickname', True)
      #### LoveMeter
      elif cmd == "lm" or cmd == "lovemeter" and not user.name in blacklist and not room.name in deathroom:
        try:
          nama1, nama2 = args.split(" ", 1)
          persen=["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","49","50","51","52","53","54","55","56","57","58","59","60","61","62","63","64","65","66","67","68","69","70","71","72","73","74","75","76","77","78","79","80","81","82","83","84","85","86","87","88","89","90","91","92","93","94","95","96","97","98","99","100"]
          hasil=random.choice(persen)
          hasil=int(hasil)
          if nama2 =="":room.message(user.name+"@ type ;lm (name1)<space>(name2)");return
          if hasil == 0:
            room.message(" Love Meter "+nama1+" with "+nama2+" = %s"% hasil+"% | Nothing! Jones forever :P")
          if hasil < 50:
            room.message(" Love Meter "+nama1+" with "+nama2+" = %s"% hasil+"% | Frindzoned!")
          if hasil > 49 and hasil < 60:
            room.message(user.name+"@ Love Meter "+nama1+" with "+nama2+" = %s"% hasil+"% | Good!")
          if hasil > 59 and hasil < 100:
             room.message(" Love Meter "+nama1+" with "+nama2+" = %s"% hasil+"% | I'm jealous *rolleyes*")
          if hasil == 100 :
            room.message(" Love Meter "+nama1+" with "+nama2+" = %s"% hasil+"% | Wohg Great! Unbelievable!")
        except:room.message(" type =lm (name1)<space>(name2)")
      elif cmd == "jones":
          if len(args)>0:
            obv = ["what do you want ?","what do you want?","what do you want","what do you desire ?","what do you desire","what do you desire?","what do you wish for?","what do you wish for ?","what do you wish for"]
            insult = ["fuck you","fook you","damn you","i hate you","kiss my ass"]
            jelas = ["apa maumu ?","apa maumu?","Apa maumu","apa maumu","mau lo apa ?","mau lo apa?","mau lo apa","lu mau apa?","lu mau apa ?","lu mau apa"]
            if args in obv:
              room.message(random.choice(["I want a girlfriend :)","I want you >:)","I need a whore","I want a lover","Your Anus !!","Your tits !","I want your soul >:3","Gimme a gun","Your money :|","Give me your money !!!"]))
            if args in jelas:
              room.message(random.choice(["Tidakkah jelas ? gue mau jablay !","Gue butuh cewek broh","hadehh dia pake nanya,, gue mau cewek"]))
            if args in insult:
              room.message(random.choice(["Well, Fuck you too","oh shit whatever >_>","Stfu and kiss my arse !!"]))
            else:
              if args in obv or args in insult or args in jelas: return
              room.message(random.choice(["yes","no","maybe","not likely","I'm too depressed right now ,try asking again later","It's a secret ;)","Still, i'm not.","True","Better not tell you now.","It is certain.","Certainly :)","I'm not sure >_>","Yes, I'am"]))
          else:
            room.message("This is The Mighty Jones command. You must ask a question for The Mighty Jones to answer...(EXAMPLE: jones Am I doing this right o.O ???)")
      elif cmd == "seen":
          try:
            nama = args
            if nama in hist:
              waktu, ruang, body = json.loads(hist[nama])
              room.message("Last message i seen by "+nama+" - "+waktu+" - "+ruang+" - "+body)
            else:
              room.message("I haven't seen " + nama + " all this days :|")
          except:
            room.message("fail")
      elif cmd == "rooms":
          j = list()
          for i in self.roomnames:
            j.append("<b>"+i+"</b>"+"("+str(self.getRoom(i).usercount)+")")
          room.message(" <f x000000='1'>I'am <f x00000='1'>Online <f x0000000='1'>in: "+", ".join(j)+" ", True)

      if cmd == "xjoin":
         if args not in self.roomnames:
                room.message("<f x00000='1'>In proggress <f x00000000='1'>go to <f x12F00='1'>room :<f x0000000='1'>  <b>%s</b>*" % args, True)
                self.joinRoom(args)
                room.message("<f x00000000='1'>I has <f x00000='1'>be in <f x00000000='1'>room :<f x0000000='1'> "+args, True)
         else: room.message("<f x0000000='1'>Sorry, <f x00000000='1'>is seems <f x1233FFFF='1'> only rank 3,4,5 <f x00000000='1'>can do this :)",True)
#### Find
      
      ##ForceSave
      if cmd == "save":
          time.sleep(1)
          print("[SAVE] SAVING DEFINITIONS...")
          f = open("definitions.txt", "w")
          for word in dictionary:
              definition, name = json.loads(dictionary[word])
              f.write(json.dumps([word, definition, name])+"\n")
          if user.name.lower() in cowner or user.name in cowner:
              room.message("Force Save Mode !)...")
          else:
              room.message("Save Mode.(Normal Mode!)")
          f.close()
     

      elif cmd == "mydf" or cmd =="mylistdef":
          arr = []
          for i in dictionary:
            if user.name in dictionary[i]:
              arr.append(i)
          if len(arr) > 0:
            room.message('<f x12FF0000="Arial">Y<f x12FF2D00="Arial">o<f x12FF5A00="Arial">u<f x12FF8700="Arial"> <f x12FFB400="Arial">h<f x12FFE100="Arial">a<f x12D2FF00="Arial">v<f x12A5FF00="Arial">e<f x1278FF00="Arial"> <f x124BFF00="Arial">d<f x121EFF00="Arial">e<f x1200FF2D="Arial">f<f x1200FF5A="Arial">i<f x1200FF87="Arial">n<f x1200FFB4="Arial">e<f x1200FFE1="Arial">d<f x1200D2FF="Arial"><b> '+str(len(arr))+'</b> words in your dictionary :<i> %s'% (', '.join(sorted(arr))), True)
          else:
            room.message("You havent defined anything to your dictionary.")


         ###### Define            
      elif cmd == "define" or cmd == "df":
          try:
            word, definition = args.split(" as ", 1)
            word = word.lower()
          except:
            word = args.split()[0].lower()
            definition = ""
          if len(definition) > 0:
            if word in dictionary:
              room.message(user.name+", sorry but <b>%s</b> is already defined" % word, True)
            else:
              dictionary[word] = json.dumps([definition, user.name])
              room.message("Brain setting to remember "+word+" "+ definition, True)
          else:
            if word in dictionary:
              definition, name = json.loads(dictionary[word])
              room.message(sntonick(name)+" defined "+word+" as "+definition , True)
            else:
              room.message("<b>%s</b> is not yet defined, do <b>=define %s as meaning</b> to define it!" % (args, args), True)
     #### Broadcast
      if cmd == "xbroadcast" or cmd == "xbc" or cmd == "xShout" or cmd == "xshout" or cmd == "xBc" or cmd == "xBc":
            if user.name in cowner or user.name in staffa: #Only rank 4+ can Broadcast a Message
                for room in self.rooms:
                  if args == "": return
                  else:
                    room.message("Broadcast de la - "+user.name + ": "+args, True)
            else:
                room.message("[<b>%s</b>] Only Admins Members are allowed" % "ERROR", True) 
      ### Wake
      if cmd == "xwake" or cmd == "xWake":
        if user.name in cowner: return
        room.message("im in wake mode")
        lockdown = False
     ### Sleep
      if cmd == "xsleep" or cmd == "xSleep":
        if user.name in cowner: return
        room.message("im in sleep mode")
        lockdown = True
      #### Dead
      elif cmd == "xshutdown" or cmd == "xDead" and user.name in cowner:
        if user.name in cowner:
          room.message("Shutting down ...")
          self.setTimeout(4, self.stop, )
          self.stop()
        else:
          room.message("???? o,o")
      # Ban List
      if cmd == "banlist":
        room.message("The banlist is: "+str(room.banlist))
      elif cmd == "xyt" or cmd == "youtube":
        if args:
          room.message(tube(args), True)
        else:
          room.message("usage /yt [keyword]")
      elif cmd == "xleave":
          if args:
                  room.message("<f x00000='1'>In Process <f x00000000='1'>Leaving <f x000000000='1'>room :<f x00000000='1'>  <b>%s</b>" % args, True)
                  self.leaveRoom(args)
                  self.leaveRoom(room.name)
          else: room.message("<f x00000='1'>Sorry, <f x000FFFF='1'>Nothing <f x00000000='1'>rank 3,4,5 <f x00000000='1'>can do <f x00000='1'>This .. ",True)
      #### Restart
      elif cmd =="xrestart" or cmd == "xRestart" or cmd == "xReconnect" or cmd == "xreconnect":
         if user.name.lower() in cowner:
           room.reconnect()
         else:
           room.message("???? o,o")
      elif cmd=="xmini":
        try:
          args=args.lower()
          stuff=str(urlreq.urlopen("http://"+args+".chatango.com").read().decode("utf-8"))
          crap,mini=stuff.split("<span class=\"profile_text\"><!-- google_ad_section_start -->",1)
          mini,crap=mini.split("<!-- google_ad_section_end --></span>",1)
          mini=mini.replace("<img","<!")
          prodata = '<br/>'+mini
          room.message(prodata,True)
        except:
          room.message(""+args+" doesn't exist o.o ")
      elif cmd == "multichat":
          if args == "":
            room.message("This multichat contains my Default Rooms - http://2pichubros.com/multijs?animeindofun,nanime")
          else:
            room.message("http://2pichubros.com/multijs?m"+args)
      elif cmd == "test":
        jawab = ["accpt"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "ramal":
        jawab = ["hari ini anda beruntung","hari ini anda sial","hari ini anda akan bertemu jodoh anda :D","hari ini anda akan ketemu mantan anda","jones ya? minta di ramal2"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "fight":
        jawab = ["http://data2.whicdn.com/images/156069110/large.gif"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "help":
        jawab = ["kumpulan perintah untuk akane >> : /dance,/fight,/crunch,/:v,/coeghdll"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "uptime":
          room.message("sys uptime: %s" % uptime())
      elif cmd == "sut":
          minute = 60
          hour = minute * 60
          day = hour * 24
          days =  int(getUptime() / day)
          hours = int((getUptime() % day) / hour)
          minutes = int((getUptime() % hour) / minute)
          seconds = int(getUptime() % minute)
          string = ""

          if days > 0:

            string += str(days) + " " + (days == 1 and "day" or "days" ) + ", "

          if len(string) > 0 or hours > 0:

            string += str(hours) + " " + (hours == 1 and "hour" or "hours" ) + ", "

          if len(string) > 0 or minutes > 0:

            string += str(minutes) + " " + (minutes == 1 and "minute" or "minutes" ) + ", "

          string += str(seconds) + " " + (seconds == 1 and "second" or "seconds" )
          room.message("bot session has been running for: %s" % string, True)
      elif cmd == "afk":
        jawab = ["bye bye"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "crunch":
        jawab = ["https://31.media.tumblr.com/50dcec4f797eb86ea483558695c874f1/tumblr_nqru66BNYc1u8lwqgo1_500.gif"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "nja":
        jawab = ["bye2"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "coeghiid":
        jawab = ["anda kenapa?"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == ":vll":
        jawab = ["emoticon dewa"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "lebaran":
        jawab = ["minal aidzin wal faizin kk"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "gue tamvan gak ?":
        jawab = ["kaga","tamvan","jelek","biasa aja"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "hmm":
        jawab = ["maho detcted"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "konbanwa":
        jawab = ["tidur sana jangan ngalong :"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "naruto":
        jawab = ["adalah anime yang selalu flash back"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "bnp":
        jawab = ["erorr forbidden access denied"]
        room.message(random.choice(jawab)+" @"+user.name)
        ##Random User
        #What's this for ? this one cmd will make your boy say the name of a random user in a room
      if cmd == "randomuser":
        room.message(random.choice(room.usernames))

  #### Bg
      if cmd =="bg":
        try:
          args=args.lower()
          picture = '<a href="http://st.chatango.com/profileimg/' + args[0] + '/' + args[1] + '/' + args + '/msgbg.jpg" style="z-index:59" target="_blank">http://fp.chatango.com/profileimg/' + args[0] + '/' + args[1] + '/' + args + '/msgbg.jpg</a>'
          prodata = '<br/>'+picture
          room.message(prodata,True)
        except:
          room.message(""+args+" doesn't exist o.o ")
 
        ##Check Level
        #This one cmd is tho make your bot say your mod level in the current room you're in
      elif cmd == "mylvl":
        room.message("Your mod level: %i" %(room.getLevel(user)))
 
        ##List Mods
        #List of Mods and Owner name in the current room you're in
      elif cmd == "xmods":
        room.message(", ".join(room.modnames + [room.ownername]))
        ##List Mods
        #List of Mods and Owner name in the current room you're in
      elif cmd == "mods" or cmd == "Mods":
        args = args.lower()
        if not args:
           room.message("<br/><font color='#9999FF'><b>Owner</b></font>:  <u><b>"+(room.ownername)+"</b></u>  <br/><font color='#9999FF'><b>Mods</b></font>: "+", ".join(room.modnames), True)
           return
        if args in self.roomnames:
           moda = self.getRoom(args).modname
           own = self.getRoom(args).ownername
           room.message("<br/><font color='#9999FF'><b>Owner</b></font>:  <b><u>"+(own)+"</u></b>  <br/><font color='#9999FF'><b>Mods</b></font>:  "+",  ".join(moda), True)
        else:
           self.joinRoom(args)
           cek_mods[user.name] = json.dumps([room.name,args])
        #### Seen
      elif cmd == "invitegroup" or cmd == "ig":
        if len (args) > 0:
         self.pm.message(ch.RoomManager(args),"%s You have group invite! check this Chatango Group http://%s.chatango.com ." %(room.ownername[0],room.name))
         room.message("Youre invite %s now is in Accest Group. :)" % args)
        else:
          room.message("gak mau ah nginvite dia")
              ### User List
      elif cmd == "ul" or cmd == "userList" or cmd == "User List" or cmd == "User list":
         if args == "":
          usrs = []
          gay = []
          finale = []
          prop = 0
          prop = prop + len(room._userlist) - 1
          for i in room._userlist:
            i = str(i)
            usrs.append(i)
          while prop >= 0:
            j = usrs[prop].replace("<User: ", "")
            i = j.replace(">", "")
            gay.append(i)
            prop = prop - 1
          for i in gay:
            if i not in finale:
              finale.append(i)
          if len(finale) > 40:
            room.message("<font color='#9999FF'><b>40</b></font> of <b>%s</b> users in this room: %s"% (len(finale), ", ".join(finale[:41])), True)
          if len(finale) <=40 :
            room.message("<f xFF0000='1'>Current <b>%s</b><f x000099='1'>users of this room: <f x3366FF='1'>%s"% (len(finale),", ".join(finale)), True)
         if args != "":
           if args not in self.roomnames:
             room.message("I'm not there.")
             return
           users = getParticipant(str(args))
           if len(users) > 40:
             room.message("<font color='#9999FF'><b>40</b></font> of <b>%s</b> current users in <b>%s</b>: %s"% (len(users), args.title(), ", ".join(users[:41])), True)
           if len(users) <=40:
             room.message("<f xFF0000='1'>Current <b>%s</b> <f x000099='1'>users in <f x3366FF='1'><b>%s</b>: %s"% (len(users), args.title(), ", ".join(users)), True)
        ##DANCE!!!!
        #Dance ? Of Course !!! ^_^
      elif cmd == "dance":
        for i, msg in enumerate(dancemoves):
          self.setTimeout(i / 2, room.message, msg)
               #### Pm
      elif cmd == "pm" or cmd == "Pm" or cmd == "PM" or cmd == "Private Message":
        data = args.split(" ", 1)
        if len(data) > 1:
          name , args = data[0], data[1]
          self.pm.message(ch.User(name), "[Private.Message] By - "+user.name+" : "+args+" ")
          room.message("Has been sent to "+name+"")
        #### Invite
      elif cmd == "invite" or cmd == "Invite":
        if len (args) > 0:
            self.pm.message(ch.RoomManager(args),"%s You have a group invite by ! http://%s.chatango.com ." %(owners[0],room.name))
            room.message("Invite on progress %s in Access group. :)" % args)
        else:
            room.message("Sry have problem. :3")
        #### Profile
      elif cmd == "prof" or cmd == "profile" or cmd == "Prof" or cmd == "Profile":
        try:
          args=args.lower()
          stuff=str(urlreq.urlopen("http://"+args+".chatango.com").read().decode("utf-8"))
          crap, age = stuff.split('<span class="profile_text"><strong>Age:</strong></span></td><td><span class="profile_text">', 1)
          age, crap = age.split('<br /></span>', 1)
          crap, gender = stuff.split('<span class="profile_text"><strong>Gender:</strong></span></td><td><span class="profile_text">', 1)
          gender, crap = gender.split(' <br /></span>', 1)
          if gender == 'M':
              gender = 'Male'
          elif gender == 'F':
              gender = 'Female'
          else:
              gender = '?'
          crap, location = stuff.split('<span class="profile_text"><strong>Location:</strong></span></td><td><span class="profile_text">', 1)
          location, crap = location.split(' <br /></span>', 1)
          crap,mini=stuff.split("<span class=\"profile_text\"><!-- google_ad_section_start -->",1)
          mini,crap=mini.split("<!-- google_ad_section_end --></span>",1)
          mini=mini.replace("<img","<!")
          picture = '<a href="http://fp.chatango.com/profileimg/' + args[0] + '/' + args[1] + '/' + args + '/full.jpg" style="z-index:59" target="_blank">http://fp.chatango.com/profileimg/' + args[0] + '/' + args[1] + '/' + args + '/full.jpg</a>'
          prodata = '<br/> <a href="http://chatango.com/fullpix?' + args + '" target="_blank">' + picture + '<br/><br/> Age: '+ age + ' <br/> Gender: ' + gender +  ' <br/> Location: ' +  location + '' '<br/> <a href="http://' + args + '.chatango.com" target="_blank"><u>Chat With User</u></a> ' "<br/><br/> "+ mini 
          room.message(prodata,True)
        except:
          room.message(""+args+" doesn't exist o.o ")
        #
        if cmd =="wordtoday" or cmd=="wt":
            if user.name in owners:
              if user.name in wordtodaytime:
                w = json.loads(wordtodaytime[user.name])
                if time.time() < w:
                  w = int(w) - int(time.time())
                  minute = 60
                  hour = minute * 60
                  day = hour * 24
                  days =  int(w / day)
                  hours = int((w % day) / hour)
                  minutes = int((w % hour) / minute)
                  seconds = int(w % minute)
                  string = ""
                  if days > 0:
                    string += str(days) + " " + (days == 1 and "day" or "days" ) + ", "
                  if len(string) > 0 or hours > 0:
                    string += str(hours) + " " + (hours == 1 and "hour" or "hours" ) + ", "
                  if len(string) > 0 or minutes > 0:
                    string += str(minutes) + " " + (minutes == 1 and "minute" or "minutes" ) + ", "
                  string += str(seconds) + " " + (seconds == 1 and "second" or "seconds" )
                  room.message("You can use wordtoday after <font color='#9999FF'>%s</font>  (~^o^)~ "% string,True)
                  return
              if urank(user.name) >= 1:
                x=(random.choice(["sadness","happines","yaoi","yuri","horny","nice","bad","bastard","young","lazy","poor","rich","ugly","handshome","beautiful","good","gay","keep calm","arrogant","naughty","special","sweet","tits","areola","pupy","ass","sunny","dizzy","nude","old","lifeless","dying",'death',"impotent","cancer"]))
                room.message("Dear "+sntonick(user.name)+" Your word today is : <b><font color='#FF9966'>"+str(x)+"</font></b>",True)
                wordtodaytime[user.name] = json.dumps(time.time()+1200)

        ##Check if Mod
        #not really important
      elif cmd == "ismod":
        user = ch.User(args)
        if room.getLevel(user) > 0:
          room.message("yes")
        else:
          room.message("nope")
   except Exception as e:
      try:
        et, ev, tb = sys.exc_info()
        lineno = tb.tb_lineno
        fn = tb.tb_frame.f_code.co_filename
        room.message("[Expectation Failed] %s Line %i - %s"% (fn, lineno, str(e)))
        return
      except:
        room.message("Undescribeable error detected !!")
        return
 
  ##Other Crap here, Dont worry about it
 
  def onFloodWarning(self, room):
    room.reconnect()
 
  def onJoin(self, room, user):
   print(user.name + " joined the chat!")
   
  def onLeave(self, room, user):
   print(user.name + " left the chat!")
   
  def onUserCountChange(self, room):
    print("users: " + str(room.usercount))
 
  def onMessageDelete(self, room, user, msg):
    print("MESSAGE DELETED: " + user.name + ": " + msg.body)
 
 
if __name__ == "__main__": TestBot.easy_start(rooms,"ItsukaAriana","1234pantek")
 
    #The End!!
