#################################################################################################################
#################################################################################################################
################################# ~ BOT REVISION BY ITSUKA REHAN ~ ##############################################
#################################################################################################################
#################################################################################################################
import ch
import sys
import re
import json
import random
import time
import datetime
import os
import urllib
from xml.etree import cElementTree as ET
if sys.version_info[0] > 2:
  import urllib.request as urlreq
else:
  import urllib2 as urlreq
from time import localtime, strftime 
wordtodaytime = dict() 
##Dance moves!
#kinda useless
 
dancemoves = [
  "(>^.^)>",
  "(v^.^)v",
]
song = [
  "Dirimu, dirimulah! Orang yang beriku senyum ini",
"Jika kita bisa membuat air mata yang bersinar, itu 'kan 'jadi bintang jatuh",
"Tanganmu t'lah terluka, tapi jangan pernah lepaskannya lagi",
"Dari langit yang terpenuhi keinginan, hari esok 'kan segera datang",

"Cahya yang membimbingku adalah dirimu",
"Dan aku pun ditarik karenanya",
"Sebelum kusadarim kita mulai sebrangi jalan itu",
"Sekaranglah saatnya! Jikalau kita hanya bisa bersinar di sini",
]

bete = [
"kunci",
]
pagi = [
"ohayou oni-chan",
]
##Rooms##
rooms = []
f = open("rooms.txt", "r") #read-only
print("[INF]Loading Rooms...")
time.sleep(1)
for name in f.readlines():
  if len(name.strip())>0: rooms.append(name.strip())
f.close()
# implied command?	
# call bot name with command after
# call bot name with command after
#Setting Pretty Colors
#Font setting for your bot
# call bot name with command after
# call bot name with command after
#Setting Pretty Colors
#Font setting for your bot
def yts(args):
  try:
    search = args.split()
    url = urllib.request.urlopen("https://www.googleapis.com/youtube/v3/search?q=%s&part=snippet&key=AIzaSyD237VSvwgQQB91jSwjCfkDCyZa4PGlYVI&order=relevance&maxResults=1" % "+".join(search))
    udict = url.read().decode('utf-8')
    data = json.loads(udict)
    nest = []
    for d in data["items"]:
      nest.append(d)
    pick=random.choice(nest)
    link = "http://www.youtube.com/watch?v=" + pick["id"]["videoId"]
    title = pick["snippet"]["title"]
    uploader = pick["snippet"]["channelTitle"]
    descript = pick["snippet"]['description']
    count    = pick["snippet"]["publishedAt"]
    k = "<br/>%s <br/><br/><br/><br/><br/><br/><br/><br/><font color='#ffcc00'><b>%s</b></font><br/><font color='#ff0000'><b>Uploader</b></font>:<b> %s</b><br/><font color='#ff0000'><b>Uploaded on</b></font>: %s<br/><font color='#ff0000'><b>Descriptions</b></font>:<i> %s ...</i><br/> " % (link, title, uploader, count, descript[:200])
    print(k)
    return k
  except Exception as e:
    return "Keyword youtube "+args+" tidak tersedia"

def tube(args):
  """
 #In case you don't know how to use this function
 #type this in the python console:
 >>> tube("pokemon dash")
 #and this function would return this thing:
 {'title': 'TAS (DS) Pok??mon Dash - Regular Grand Prix', 'descriptions': '1st round Grand Prix but few mistake a first time. Next Hard Grand Prix will know way and few change different Pok??mon are more faster and same course Cup.', 'uploader': 'EddieERL', 'link': 'http://www.youtube.com/watch?v=QdvnBmBQiGQ', 'videoid': 'QdvnBmBQiGQ', 'viewcount': '2014-11-04T15:43:15.000Z'}
 """
  search = args.split()
  url = urlreq.urlopen("https://www.googleapis.com/youtube/v3/search?q=%s&part=snippet&key=AIzaSyD237VimoPwCa46pN4DupvePQpGx2D2wbkNoGlYVI" % "+".join(search))
  udict = url.read().decode('utf-8')
  data = json.loads(udict)
  rest = []
  for f in data["items"]:
    rest.append(f)
 
  d = random.choice(rest)
  link = "http://www.youtube.com/watch?v=" + d["id"]["videoId"]
  videoid = d["id"]["videoId"]
  title = d["snippet"]["title"]
  uploader = d["snippet"]["channelTitle"]
  descript = d["snippet"]['description']
  count    = d["snippet"]["publishedAt"]
  return "<br/>%s <br/><br/><br/><br/><br/><br/><br/><br/><font color='#ffcc00'><b>%s</b></font><br/><font color='#ff0000'><b>Uploader</b></font>:<b> %s</b><br/><font color='#ff0000'><b>Uploaded on</b></font>: %s<br/><font color='#ff0000'><b>Descriptions</b></font>:<i> %s ...</i><br/> " % (link, title, uploader, count, descript[:200])
# call bot name with command after
# call bot name with command after
#Setting Pretty Colors
#Font setting for your bot
def pm(args):
        user = ch.User(args)
        func = lambda a, b: a.pm._status[b]
        last_on,is_on,idle = func(self, user)
        if is_on == True:
          if idle == 0: room.message(args.capitalize()+" is online and idle for 0 sec",True);return
          else:
                      w = idle
                      w = int(time.time()) - int(w)
                      minute = 60
                      hour = minute * 60
                      day = hour * 24
                      days =  int(w / day)
                      hours = int((w % day) / hour)
                      minutes = int((w % hour) / minute)
                      seconds = int(w % minute)
                      string = " is online and idle for "
                      if days > 0:
                        string += str(days) + " " + (days == 1 and "d" or "d" ) + ", "
                      if hours > 0:
                        string += str(hours) + " " + (hours == 1 and "hr" or "hrs" ) + ", "
                      if minutes > 0:
                        string += str(minutes) + " " + (minutes == 1 and "min" or "mins" ) + ". "
                      room.message(args.capitalize()+string,True)
        else:
          if last_on == 0: room.message(args.capitalize()+" is offline",True);return
          else:
                      w = last_on
                      w = int(time.time()) - int(w)
                      minute = 60
                      hour = minute * 60
                      day = hour * 24
                      days =  int(w / day)
                      hours = int((w % day) / hour)
                      minutes = int((w % hour) / minute)
                      seconds = int(w % minute)
                      string = " is offline for "
                      if days > 0:
                        string += str(days) + " " + (days == 1 and "d" or "d" ) + ", "
                      if hours > 0:
                        string += str(hours) + " " + (hours == 1 and "hr" or "hrs" ) + ", "
                      if minutes > 0:
                        string += str(minutes) + " " + (minutes == 1 and "min" or "mins" ) + ". "
                      room.message(args.capitalize()+string,True)

##COMMAN 
##COMMAN
class TestBot(ch.RoomManager):
  def onInit(self):
    self.setNameColor("000")
    self.setFontColor("000")
    self.setFontFace("1")
    self.setFontSize(11)
    self.enableBg()
    self.enableRecording()
##### Pars Def
  def pars(args):
          args=args.lower()
          userlist = roomUsers()
          for name in userlist:
            if args in name:return name  
##Connecting Crap
#This is what will be printed on your python console when event called
 
  def onConnect(self, room):
    print("Connected")
 
  def onReconnect(self, room):
    print("Reconnected")
 
  def onDisconnect(self, room):
    print("Disconnected")
 

##Ignore this, you dont need to worry about this
#Well, you can actually take a little time to look at it and learn something
  def onMessage(self, room, user, message):
  #### Comenzi fara prefix
   if message.body.startswith("lel"):
     room.message("kamu baik2 saja?  @"+user.name+".")
   if message.body.startswith("aku minta maaf ya"):
     room.message("iya tidak apa  @"+user.name+".")
   if message.body.startswith("domain nekopoi sekarang apa?"):
     room.message(".care")
   if message.body.startswith("akane mana yang lainnya"):
     room.message("mungkin sekolah atau sedang sibuk  @"+user.name+".")
   if message.body.startswith("akane bagaimana kabarmu"):
     room.message("aku baik baik saja  @"+user.name+".")
   if message.body.startswith("tempat yang paling bagus buat baca horror di mana ya"):
     room.message("pemakamans.blogspot.com  @"+user.name+".")
   if message.body.startswith("off"):
     room.message("Ok, besok on lagi ya kk  @"+user.name+".")
   if message.body.startswith("afk"):
     room.message("dadah  @"+user.name+".")
   if message.body.startswith("neko?"):
     room.message("dimana neko nya?  @"+user.name+".")
   if message.body.startswith("moons"):
     room.message("iya ada apa?   @"+user.name+".")
   if message.body.startswith("moons apakah aku cantik"):
     room.message("ya  @"+user.name+".")
   if message.body.startswith("moons apakah aku tampan"):
     room.message("ya  @"+user.name+".")
   if message.body.startswith("moons siapa penciptamu"):
     room.message("internet")
   if message.body.startswith("hayy"):
     room.message("haii")
   if message.body.startswith("test"):
     room.message("hmm  @"+user.name+".")
   if message.body.startswith("woie"):
     room.message("apa woi ?")
   if message.body.startswith("sepi"):
     room.message("bakar rumah mu saja :")
   if message.body.startswith("siang"):
     room.message("selamat siang :)")
   if message.body.startswith("malam"):
     room.message("selamat malam :)")
   if message.body.startswith("konbawa"):
     room.message("Konbawa")
   if message.body.startswith("oyasumi"):
     room.message("hai, oyasumi :v")
   if message.body.startswith("konichiwa"):
     room.message("hai, konichiwa :)")
   if message.body.startswith("xtime"):
      room.message(strftime("%H:%M:%S", localtime()))      
   if message.body.startswith("xdate"):
     room.message(strftime ("Day: %a,%d-%b-%Y ", localtime()))
   if message.body.startswith("siapa yang paling cantik"):
     room.message("kamu  @"+user.name+".")
   if message.body.startswith("wkkwkwkkw"):
     room.message("kamu baik2 saja  @"+user.name+".")
   if message.body.startswith("aku jahat apa baik ?"):
     jawab = ["jahat","siapa ya? ","baik","pffft :v","coegh"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("halo"):
     room.message("iya halo juga")
   if message.body.startswith("cmds"):
     room.message("kamu harus lvl 1 untuk memakainya") 
   if message.body.startswith("kamu udah makan moons ?"):
     jawab = ["aku tidak perlu makan, minum atau buang air"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("moons lagi apa ?"):
     jawab = ["lagi mikrin kamu","lagi bobo","lagi maen dota","siapa ya?","jones ya ?"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("my colors ?"):
     jawab = ["hijau","pelangi","kuning","merah","biru","hitam","ungu","siapa yah ?"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("hai moons"):
     jawab = ["siapa ya ?","hem mungkin","siapa yah ?"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith(" moons lu gapain di sini ?"):
     jawab = ["afk nonton anime"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("kamu suka gak sama aku ?"):
     jawab = ["iya","engak","siapa yah?","suka bnget"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("gue cantik gak moons?"):
     jawab = ["kurang","siapa ya? ","cantik","cantik sih, tapi masih cantikan aku","jones yah ?"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("gue tamvan gak moons?"):
     jawab = ["jelek","siapa ya? ","tamvan","iya kk ganteng deh, aku suka sama kk","jones yah ?"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("tampan gak dia "):
     jawab = ["jelek","siapa ya? ","tamvan","iya kk ganteng deh, aku suka sama kk","jones yah ?"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("soalnya kamu"):
     jawab = ["boleh juga","garing","lagi dong","so swet","siapa yah ?"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("karena kamu"):
     jawab = ["boleh juga","garing","lagi dong","so swet","siapa yah ?"]
     room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("asal kamu dari mana moons?"):
     room.message("aku ini sebuah makhluk yang di ciptakan oleh gugun dan aku tidak tau aku berasal dari mana")
   if message.body.startswith("kunci"):
     room.message("muah !!, http://media.giphy.com/media/X3ndlrK6rOCt2/giphy.gif")   
   if message.body.startswith("kunci"):
     room.message(" you want kiss me ?, http://vignette1.wikia.nocookie.net/dundef/images/3/3a/Kawaii-anime-girl-3-kawaii-anime-34732047-400-440.png answer ? (yes,no)  @"+ user.name+".")
   if message.body.startswith("Amoons"):
     room.message("hai!, moons, https://s-media-cache-ak0.pinimg.com/736x/ba/d6/85/bad685e5009bed204ad5aea4ceb16136.jpg ada yang bisa di bantu @"+ user.name+".")
   if message.body.startswith("pagei"):
     for i, msg in enumerate(pagi):
        self.setTimeout(i / 2, room.message, msg)
   if message.body.startswith("bete nih"):
     for i, msg in enumerate(bete):
        self.setTimeout(i / 0.79, room.message, msg)
   if message.body.startswith("nyaasnn"):
      for i, msg in enumerate():
        self.setTimeout(i / 2, room.message, msg)
   if message.body.startswith("kunkuci"):
      for i, msg in enumerate(simponi):
        self.setTimeout(i / 0.79, room.message, msg)
   if message.body.startswith("kata bijak"):
      room.message(random.choice(["jangan lah berhenti bermimpi karena mimpi bisa itu suatu saat akan menjadi nyata.",
          "berani ambil resiko, kita tidak akan pernah tau apa yang akan terjadi.",
          "jangan pernah lupa dengan orang yang selalu mendukung mu dari belakang.",
          "jangan pernah sekali-kali sombong, karena di atas langit masih ada langit.",
          "To true friendship, how long you've known each other means nothing.",
          "You want weapons? We??re in a library! Books! The best weapons in the world!",
          "mulut lebih tajam dari benda apapun kalu kita salah menggunakan nya.",
          "Dividing an impossibly large task into smaller solvable problems is a programmer??s job.",
          "dunia ini penuh dengan melodi dan harmoni, jangan sekali2 merusak nya dengan keluhan anda :)",
          "Hold hands. That's what you're meant to do. Keep doing that... and don't let go.",
          "cintailah orang yang mencintai anda juga?",
          "jangan pernah malah olahraga",
          "Don't worry if plan A fails, there are 25 more letters in the alphabet.",
          "Life doesn't have any hands, but it can sure give you a slap sometimes.",
          "lihat ke belakang, sewaktu2 jika anda tidak sedang sibuk",
          "Belajar ketika orang lain tidur, bekerja ketika orang lain bermalasan, dan bermimpi ketika orang lain berharap.",
          "Pain has deep roots. The only way to dig it out is to forgive...",
          "Love,after all,always said more about those who felt it then it did about the ones they love.",
          "Memories are funny things.Sometimes they're real ,but other times they change into what we went them to be.",
          "The moment of impact. The moment of impact proves potential for change. Has ripples effects far beyond what we can predict."]))
   if message.body.startswith("xquotes"):
      room.message(random.choice(["jangan lah berhenti bermimpi karena mimpi bisa itu suatu saat akan menjadi nyata.",
          "berani ambil resiko, kita tidak akan pernah tau apa yang akan terjadi.",
          "jangan pernah lupa dengan orang yang selalu mendukung mu dari belakang.",
          "jangan pernah sekali-kali sombong, karena di atas langit masih ada langit.",
          "To true friendship, how long you've known each other means nothing.",
          "You want weapons? We??re in a library! Books! The best weapons in the world!",
          "mulut lebih tajam dari benda apapun kalu kita salah menggunakan nya.",
          "Dividing an impossibly large task into smaller solvable problems is a programmer??s job.",
          "dunia ini penuh dengan melodi dan harmoni, jangan sekali2 merusak nya dengan keluhan anda :)",
          "Hold hands. That's what you're meant to do. Keep doing that... and don't let go.",
          "cintailah orang yang mencintai anda juga?",
          "jangan pernah malah olahraga",
          "Don't worry if plan A fails, there are 25 more letters in the alphabet.",
          "Life doesn't have any hands, but it can sure give you a slap sometimes.",
          "lihat ke belakang, sewaktu2 jika anda tidak sedang sibuk",
          "Belajar ketika orang lain tidur, bekerja ketika orang lain bermalasan, dan bermimpi ketika orang lain berharap.",
          "Pain has deep roots. The only way to dig it out is to forgive...",
          "Love,after all,always said more about those who felt it then it did about the ones they love.",
          "Memories are funny things.Sometimes they're real ,but other times they change into what we went them to be.",
          "The moment of impact. The moment of impact proves potential for change. Has ripples effects far beyond what we can predict."]))
   if message.body.startswith("ramalan jodoh"):
     room.message("masukan nama mu dan pasangan mu contoh >> mr.x dan ms.y setelah itu tulis >> ramal")
   if message.body.startswith("gua cocok gak sama"):
      jawab = ["cocok","gak cocok","gak pantes","saling suka :)",]
      room.message(random.choice(jawab)+" @"+user.name)
   if message.body.startswith("brb"):
     if user.name == "noss":
      room.message("jangan balik lagi ya")
     else:
      room.message("sampai ketemu lagi  "  + user.name+".")
   if message.body.startswith("back"):
     if user.name == "noss":
      room.message("ngapain balik lagi lu coeg :v ?")
     else:
      room.message("selamat datang  tuan/nyonya   "  + user.name+".")
   try:
    if room.getLevel(self.user) > 0:
      print(user.name, message.body)
    else:
      print(user.name, message.body)
    if self.user == user: return
    if message.body[0] == "x" :   ##Here is the Prefix part
      data = message.body[1:].split(" ", 1)
      if len(data) > 1:
        cmd, args = data[0], data[1]
      else:
        cmd, args = data[0], ""

      def roompars(args):
        args = args.lower()
        for name in self.roomnames:
          if args in name:return name
      def roomUsers():
          usrs = []
          gay = []
          prop = 0
          prop = prop + len(room._userlist) - 1
          for i in room._userlist:
            i = str(i)
            usrs.append(i)
          while prop >= 0:
            j = usrs[prop].replace("<User: ", "")
            i = j.replace(">", "")
            gay.append(i)
            prop = prop - 1
          return gay
      
      def getParticipant(arg):
          rname = self.getRoom(arg)
          usrs = []
          gay = []
          finale = []
          prop = 0
          prop = prop + len(rname._userlist) - 1
          for i in rname._userlist:
            i = str(i)
            usrs.append(i)
          while prop >= 0:
            j = usrs[prop].replace("<User: ", "")
            i = j.replace(">", "")
            gay.append(i)
            prop = prop - 1
          for j in gay:
            if j not in finale:
              finale.append(j)
          return finale
##COMMANDS!
      if cmd == "yt" or cmd == "youtube":
        if args:
          room.message(yts(args),True)
        else:
          room.message("Please type what you want to watch in Youtube..",True)
#Setting up commands for yer bot
 #commands section
#### Invite
      if cmd == "invite" or cmd == "Invite":
        if len (args) > 0:
            self.pm.message(ch.RoomManager(args),"%s You have a group invite by ! http://%s.chatango.com ." %(owners[0],room.name))
            room.message("Invite on progress %s in Access group. :)" % args)
        else:
            room.message("Sry have problem. :3")
##You may want/need to evaluate something about your bot.
      if cmd == "ev" or cmd == "eval" or cmd == "e":
          ret = eval(args)
          if ret == None:
            room.message("Done.")
            return
          room.message(str(ret))
      if cmd.lower() == "fpix" and len (args) > 0:
        if self.getAccess(user) >= 0:
            name=args
            room.message("http://fp.chatango.com/profileimg/"+name[:1]+"/"+name[1:2]+"/"+name+"/full.jpg")
        ##bgtime
        if cmd == "bgtime" or cmd == "bgt":
           if args:
            if " " in args.lower():
              room.message(args.lower()+" does not exist.", True)
            else:
              if len(args.split(" ", -1)) != 1:
                return
              if len(args) == 1:
                f_args, s_args = args, args
              elif len(args) > 1:
                f_args, s_args = args[0], args[1]
     
              def Bgtime(args):
                try:
                  expired = True
                  url = ("http://st.chatango.com/profileimg/"+f_args+"/"+s_args+"/"+args+"/mod1.xml")
                  f = urlreq.urlopen(url)
                  data = f.read().decode("utf-8")
                  e = ET.XML(data)
                  bg = e.findtext("d")
                  bg = int(urlreq.unquote(bg))
                  if bg - int(time.time()) < 0:
                    total_seconds = int(time.time())-bg
                    aa = str(datetime.datetime.fromtimestamp(bg).strftime("%A, %d %B %Y (%I:%M %p)"))
                  else:
                    total_seconds = bg-int(time.time())
                    aa = str(datetime.datetime.fromtimestamp(bg).strftime("%A, %d %B %Y (%I:%M %p)"))
                    expired = False
     
                  MINUTE = 60
                  HOUR   = MINUTE * 60
                  DAY    = HOUR * 24
                  MONTH = DAY * 30
                  YEAR = MONTH * 12

                  years = int( total_seconds / YEAR )
                  months = int( ( total_seconds % YEAR ) / MONTH )
                  days   = int( ( total_seconds % MONTH ) / DAY )
                  hours   = int( ( total_seconds % DAY ) / HOUR )
                  minutes = int( ( total_seconds % HOUR ) / MINUTE )
                  seconds = int( total_seconds % MINUTE )
                  string = ""
                  if years > 0 or years < 0:
                    string += str(years) + " " + (years == 1 and "year" or "years" ) + ", "
                  if months > 0 or months < 0:
                    string += str(months) + " " + (months == 1 and "month" or "months" ) + ", "
                  if days > 0 or days < 0:
                    string += str(days) + " " + (days == 1 and "day" or "days" ) + ", "
                  if len(string) > 0 or hours > 0:
                    string += str(hours) + " " + (hours == 1 and "hour" or "hours" ) + ", "
                  if len(string) > 0 or minutes > 0:
                    string += str(minutes) + " " + (minutes == 1 and "minute" or "minutes" ) + ", "
                  string += str(seconds) + " " + (seconds == 1 and "second" or "seconds" )
                  love=urlreq.urlopen("http://fp.chatango.com/profileimg/"+args[0]+"/"+args[1]+"/"+args+"/msgbg.xml").read().decode()
                  love=dict([x.replace('"', '').split("=") for x in re.findall('(\w+=".*?")', love)[1:]])
                  p = love["bgc"]
                  c = love["bgalp"]
                  b = love["ialp"]
                  l = love["useimg"]
                  t = love["align"]
                  if "tr" in t:
                      lk = "Top Right"
                  if "tl" in t:
                      lk = "Top Left"
                  if "br" in t:
                      lk = "Bottom Rigth"
                  if "bl" in t:
                      lk = "Bottom Left"
                  if "1" in l:
                       mn = "yes"
                  else:
                        mn = "no"
                  if "yes" in mn:
                       gambar = "http://fp.chatango.com/profileimg/"+args.lower()[:1]+"/"+args.lower()[1:2]+"/"+args.lower()+"/msgbg.jpg"
                  else:
                      gambar = "Doesn't Have Image"
                  m = love["tile"]
                  if "1" in m:
                       ea = "yes"
                  else:
                        ea = "no"
                  if expired == True:
                    return ""+gambar+"<br/>Expired : "+string+" ago<br/>Date : "+aa+"ago <br/>Color : #"+p+"<br/>Transparency : BG : "+c+"% IMG : "+b+"%"+"<br/>Use Image : "+mn+"<br/>Tile : "+ea+"<br/>Align : "+lk+""
                  elif expired == False:
                    return ""+gambar+"<br/>Remaining : "+string+"<br/>Date : "+aa+"<br/>Color : #"+p+"<br/>Transparency : BG : "+c+"% IMG : "+b+"%"+"<br/>Use Image : "+mn+"<br/>Tile : "+ea+"<br/>Align : "+lk+""
                except:
                  return "Never had background."
              room.message("<br/><b>User : "+args.title()+"</b><br/><br/>"+Bgtime(args), True)
           else:
            room.message("<b>Do +bgtime (username)</b>", True)
        ##cso
        if cmd == "cso":
          if not args:
              room.message("Usage : +cso <b>[user name]</b>")
          if args:
            self.pm.addContact(ch.User(args))
            self.setTimeout(2, self.pm.track, (ch.User(args)))
            self.setTimeout(5, pm, (args))
        ##Say
        #Make your bot say what you want
      if cmd == "say":
       if args:
        room.message(args)
       else:
        room.message(":|")
      elif cmd == "cmds" or cmd =="command":
        room.message("Available Command: <br/> yt , prof , pm ,   quotes , time , join , leave , mylvl ,ramal , help , say , ru , invite , rooms , mods , date , afk ,ismod , ig , ul , ev , bg , find ,", True)
      elif cmd == "rooms":
          j = list()
          for i in self.roomnames:
            j.append("<b>"+i+"</b>"+"("+str(self.getRoom(i).usercount)+")")
          room.message(" <f x000000='1'>I'am <f x00000='1'>Online <f x0000000='1'>in: "+", ".join(j)+" ", True)

      if cmd == "xjoin":
         if args not in self.roomnames:
                room.message("<f x00000='1'>In proggress <f x00000000='1'>go to <f x12F00='1'>room :<f x0000000='1'>  <b>%s</b>*" % args, True)
                self.joinRoom(args)
                room.message("<f x00000000='1'>I has <f x00000='1'>be in <f x00000000='1'>room :<f x0000000='1'> "+args, True)
         else: room.message("<f x0000000='1'>Sorry, <f x00000000='1'>is seems <f x1233FFFF='1'> only rank 3,4,5 <f x00000000='1'>can do this :)",True)
#### Find
      elif cmd == "find" or cmd == "Find":
          name = args.split()[0].lower()
          try:
            if name in room.usernames:
                    if not ch.User(name).roomnames:  room.message("dont see them. o,o")
                    else: room.message("<f xFF0000='1'><b>%s</b><f x999900='1'>is curently in <f x3366FF='1'><b>%s</b> o/o" % (args, ", ".join(ch.User(name).roomnames)), True)
          except: return
          target = args[1:]
          if args[0] == "+":
                if not ch.User(target).roomnames:  room.message("dont see them. o,o")
                else: room.message("<f xFF0000='1'><b>%s</b><f x000099='1'> is curently in <f x3366FF='1'><b>%s</b> >_>" % (args[1:], ", ".join(ch.User(target).roomnames)), True)      
      elif cmd == "xleave":
          if args:
                  room.message("<f x00000='1'>In Process <f x00000000='1'>Leaving <f x000000000='1'>room :<f x00000000='1'>  <b>%s</b>" % args, True)
                  self.leaveRoom(args)
                  self.leaveRoom(room.name)
          else: room.message("<f x00000='1'>Sorry, <f x000FFFF='1'>Nothing <f x00000000='1'>rank 3,4,5 <f x00000000='1'>can do <f x00000='1'>This .. ",True)
      elif cmd=="^mini":
        try:
          args=args.lower()
          stuff=str(urlreq.urlopen("http://"+args+".chatango.com").read().decode("utf-8"))
          crap,mini=stuff.split("<span class=\"profile_text\"><!-- google_ad_section_start -->",1)
          mini,crap=mini.split("<!-- google_ad_section_end --></span>",1)
          mini=mini.replace("<img","<!")
          prodata = '<br/>'+mini
          room.message(prodata,True)
        except:
          room.message(""+args+" doesn't exist o.o ")
      elif cmd == "test":
        jawab = ["accpt"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "ramal":
        jawab = ["hari ini anda beruntung","hari ini anda sial","hari ini anda akan bertemu jodoh anda :D","hari ini anda akan ketemu mantan anda","jones ya? minta di ramal2"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "fight":
        jawab = ["http:h//data2.whicdn.com/images/156069110/large.gif"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "help":
        jawab = ["kumpulan perintah untuk akane >> : /dance,/fight,/crunch,/:v,/coeghdll"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "afk":
        jawab = ["bye bye"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "crunch":
        jawab = ["https://31.media.tumblr.com/50dcec4f797eb86ea483558695c874f1/tumblr_nqru66BNYc1u8lwqgo1_500.gif"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "nja":
        jawab = ["bye2"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "coeghiid":
        jawab = ["anda kenapa?"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == ":vll":
        jawab = ["emoticon dewa"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "lebaran":
        jawab = ["minal aidzin wal faizin kk"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "gue tamvan gak ?":
        jawab = ["kaga","tamvan","jelek","biasa aja"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "hmm":
        jawab = ["maho detcted"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "konbanwa":
        jawab = ["tidur sana jangan ngalong :"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "naruto":
        jawab = ["adalah anime yang selalu flash back"]
        room.message(random.choice(jawab)+" @"+user.name)
      elif cmd == "bnp":
        jawab = ["erorr forbidden access denied"]
        room.message(random.choice(jawab)+" @"+user.name)
        ##Random User
        #What's this for ? this one cmd will make your boy say the name of a random user in a room
      if cmd == "ru":
        room.message(random.choice(room.usernames))
     #### MyIp
      if cmd =="^myip" or cmd == "MyIp" or cmd == "MyIP" or cmd == "My IP Adress":
        try:
         room.message("Your I.P. address is : "+message.ip)
        except:
         room.message("IP lookup failed , bot is not a mod in this chat.")
  #### Bg
      if cmd =="bg":
        try:
          args=args.lower()
          picture = '<a href="http://st.chatango.com/profileimg/' + args[0] + '/' + args[1] + '/' + args + '/msgbg.jpg" style="z-index:59" target="_blank">http://fp.chatango.com/profileimg/' + args[0] + '/' + args[1] + '/' + args + '/msgbg.jpg</a>'
          prodata = '<br/>'+picture
          room.message(prodata,True)
        except:
          room.message(""+args+" doesn't exist o.o ")
 
        ##Check Level
        #This one cmd is tho make your bot say your mod level in the current room you're in
      elif cmd == "mylvl":
        room.message("Your mod level: %i" %(room.getLevel(user)))
 
        ##List Mods
        #List of Mods and Owner name in the current room you're in
      elif cmd == "mods":
        room.message(", ".join(room.modnames + [room.ownername]))
        #### Seen
      elif cmd == "invitegroup" or cmd == "ig":
        if len (args) > 0:
         self.pm.message(ch.RoomManager(args),"%s You have group invite! check this Chatango Group http://%s.chatango.com ." %(room.ownername[0],room.name))
         room.message("Youre invite %s now is in Accest Group. :)" % args)
        else:
          room.message("gak mau ah nginvite dia")
              ### User List
      elif cmd == "ul" or cmd == "userList" or cmd == "User List" or cmd == "User list":
         if args == "":
          usrs = []
          gay = []
          finale = []
          prop = 0
          prop = prop + len(room._userlist) - 1
          for i in room._userlist:
            i = str(i)
            usrs.append(i)
          while prop >= 0:
            j = usrs[prop].replace("<User: ", "")
            i = j.replace(">", "")
            gay.append(i)
            prop = prop - 1
          for i in gay:
            if i not in finale:
              finale.append(i)
          if len(finale) > 40:
            room.message("<font color='#9999FF'><b>40</b></font> of <b>%s</b> users in this room: %s"% (len(finale), ", ".join(finale[:41])), True)
          if len(finale) <=40 :
            room.message("<f xFF0000='1'>Current <b>%s</b><f x000099='1'>users of this room: <f x3366FF='1'>%s"% (len(finale),", ".join(finale)), True)
         if args != "":
           if args not in self.roomnames:
             room.message("I'm not there.")
             return
           users = getParticipant(str(args))
           if len(users) > 40:
             room.message("<font color='#9999FF'><b>40</b></font> of <b>%s</b> current users in <b>%s</b>: %s"% (len(users), args.title(), ", ".join(users[:41])), True)
           if len(users) <=40:
             room.message("<f xFF0000='1'>Current <b>%s</b> <f x000099='1'>users in <f x3366FF='1'><b>%s</b>: %s"% (len(users), args.title(), ", ".join(users)), True)
        ##DANCE!!!!
        #Dance ? Of Course !!! ^_^
      elif cmd == "dance":
        for i, msg in enumerate(dancemoves):
          self.setTimeout(i / 2, room.message, msg)
               #### Pm
      elif cmd == "pm" or cmd == "Pm" or cmd == "PM" or cmd == "Private Message":
        data = args.split(" ", 1)
        if len(data) > 1:
          name , args = data[0], data[1]
          self.pm.message(ch.User(name), "[Private.Message] By - "+user.name+" : "+args+" ")
          room.message("Has been sent to "+name+"")
        #### Invite
      elif cmd == "invite" or cmd == "Invite":
        if len (args) > 0:
            self.pm.message(ch.RoomManager(args),"%s You have a group invite by ! http://%s.chatango.com ." %(owners[0],room.name))
            room.message("Invite on progress %s in Access group. :)" % args)
        else:
            room.message("Sry have problem. :3")
        #### Profile
      elif cmd == "prof" or cmd == "profile" or cmd == "Prof" or cmd == "Profile":
        try:
          args=args.lower()
          stuff=str(urlreq.urlopen("http://"+args+".chatango.com").read().decode("utf-8"))
          crap, age = stuff.split('<span class="profile_text"><strong>Age:</strong></span></td><td><span class="profile_text">', 1)
          age, crap = age.split('<br /></span>', 1)
          crap, gender = stuff.split('<span class="profile_text"><strong>Gender:</strong></span></td><td><span class="profile_text">', 1)
          gender, crap = gender.split(' <br /></span>', 1)
          if gender == 'M':
              gender = 'Male'
          elif gender == 'F':
              gender = 'Female'
          else:
              gender = '?'
          crap, location = stuff.split('<span class="profile_text"><strong>Location:</strong></span></td><td><span class="profile_text">', 1)
          location, crap = location.split(' <br /></span>', 1)
          crap,mini=stuff.split("<span class=\"profile_text\"><!-- google_ad_section_start -->",1)
          mini,crap=mini.split("<!-- google_ad_section_end --></span>",1)
          mini=mini.replace("<img","<!")
          picture = '<a href="http://fp.chatango.com/profileimg/' + args[0] + '/' + args[1] + '/' + args + '/full.jpg" style="z-index:59" target="_blank">http://fp.chatango.com/profileimg/' + args[0] + '/' + args[1] + '/' + args + '/full.jpg</a>'
          prodata = '<br/> <a href="http://chatango.com/fullpix?' + args + '" target="_blank">' + picture + '<br/><br/> Age: '+ age + ' <br/> Gender: ' + gender +  ' <br/> Location: ' +  location + '' '<br/> <a href="http://' + args + '.chatango.com" target="_blank"><u>Chat With User</u></a> ' "<br/><br/> "+ mini 
          room.message(prodata,True)
        except:
          room.message(""+args+" doesn't exist o.o ")
        #
        if cmd =="wordtoday" or cmd=="wt":
            if user.name in owners:
              if user.name in wordtodaytime:
                w = json.loads(wordtodaytime[user.name])
                if time.time() < w:
                  w = int(w) - int(time.time())
                  minute = 60
                  hour = minute * 60
                  day = hour * 24
                  days =  int(w / day)
                  hours = int((w % day) / hour)
                  minutes = int((w % hour) / minute)
                  seconds = int(w % minute)
                  string = ""
                  if days > 0:
                    string += str(days) + " " + (days == 1 and "day" or "days" ) + ", "
                  if len(string) > 0 or hours > 0:
                    string += str(hours) + " " + (hours == 1 and "hour" or "hours" ) + ", "
                  if len(string) > 0 or minutes > 0:
                    string += str(minutes) + " " + (minutes == 1 and "minute" or "minutes" ) + ", "
                  string += str(seconds) + " " + (seconds == 1 and "second" or "seconds" )
                  room.message("You can use wordtoday after <font color='#9999FF'>%s</font>  (~^o^)~ "% string,True)
                  return
              if urank(user.name) >= 1:
                x=(random.choice(["sadness","happines","yaoi","yuri","horny","nice","bad","bastard","young","lazy","poor","rich","ugly","handshome","beautiful","good","gay","keep calm","arrogant","naughty","special","sweet","tits","areola","pupy","ass","sunny","dizzy","nude","old","lifeless","dying",'death',"impotent","cancer"]))
                room.message("Dear "+sntonick(user.name)+" Your word today is : <b><font color='#FF9966'>"+str(x)+"</font></b>",True)
                wordtodaytime[user.name] = json.dumps(time.time()+1200)

        ##Check if Mod
        #not really important
      elif cmd == "ismod":
        user = ch.User(args)
        if room.getLevel(user) > 0:
          room.message("yes")
        else:
          room.message("nope")
   except Exception as e:
      try:
        et, ev, tb = sys.exc_info()
        lineno = tb.tb_lineno
        fn = tb.tb_frame.f_code.co_filename
        room.message("[Expectation Failed] %s Line %i - %s"% (fn, lineno, str(e)))
        return
      except:
        room.message("Undescribeable error detected !!")
        return
 
  ##Other Crap here, Dont worry about it
 
  def onFloodWarning(self, room):
    room.reconnect()
 
  def onJoin(self, room, user):
   print(user.name + " joined the chat!")
   
  def onLeave(self, room, user):
   print(user.name + " left the chat!")
   
  def onUserCountChange(self, room):
    print("users: " + str(room.usercount))
 
  def onMessageDelete(self, room, user, msg):
    print("MESSAGE DELETED: " + user.name + ": " + msg.body)
 
 
if __name__ == "__main__": TestBot.easy_start(rooms,"hzuki","asd1234567")
 
    #The End!!
